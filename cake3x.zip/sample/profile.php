<?php 

session_start();

if(!isset($_SESSION['userid'])){
    header('location:login.php');
}
    $app = "<script src='js/app.register.js'></script>";
    $username = isset($_SESSION['username']) ? $_SESSION['username'] : '';
    $fullname = isset($_SESSION['fullname']) ? $_SESSION['fullname'] : '';
    $address = isset($_SESSION['address']) ? $_SESSION['address'] : '';
    $mobile = isset($_SESSION['mobile']) ? $_SESSION['mobile'] : '';
    $email = isset($_SESSION['email']) ? $_SESSION['email'] : '';
    $password = isset($_SESSION['password']) ? $_SESSION['password'] : '';
    $role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
?>
<!DOCTYPE html>
<html>
<head>
 <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style.css">
    <title>User list</title>
</head>
<style>
    body{

        align-items: center;
    background-size: cover;
    background-position: center center;
      margin: 0;
    padding: 0;
    font-family: sans-serif;
    background: linear-gradient(to right,skyblue,white);
    }
</style>
<body>
        <div id="register-app">
     <!-- header section start here  -->
     <header class="header">
        <div class="logoContent">
            <a href="#" class="logo"><img src="img/logo.png" alt=""></a>
            <h1 class="logoName">CakeEace </h1>
        </div>

        <nav class="navbar">
            <a href="#home">HOME</a>
            <a href="#ABOUT">ABOUT</a>
            <a href="products.php">MENU</a>
            <a href="reserve.php">RESERVE</a>
            <a href="#contact">CONTACT</a>
            <div class="dropdown">
  <a class="dropdown-toggle"  data-bs-toggle="dropdown" aria-expanded="false">
  Account
</a>
  <ul class="dropdown-menu">
    <li><a class="dropdown-item" href="profile.php">Profile</a></li>
    <li><a class="dropdown-item" href="logout.php">Logout</a></li>
  </ul>
</div>
        </nav>

        <div class="icon">
            <i class="fas fa-search" id="search"></i>
            <i class="fas fa-bars" id="menu-bar"></i>
        </div>

        <div class="search">
            <input type="search" placeholder="search...">
        </div>
    </header>



            <div class="container " style="margin-top:150px; " >
            <div class="col-md-6">  
            <img src="img/cake2.png" alt="image" style="width:70px; height:100px;  display: block;margin-left: auto;margin-right: auto;">  
            <h1 class="form-control mb-4 "> <?php echo $username; ?></h1>
            <h1 class="form-control mb-4">  <?php echo $fullname; ?></h1>
            <h1 class="form-control mb-4"> <?php echo $address; ?></h1>
            <h1 class="form-control mb-4"> <?php echo $mobile; ?></h1>
            <h1 class="form-control mb-4"><?php echo $email; ?></h1>
           <h1 class="form-control mb-4"> <?php echo $password; ?></h1> 


               
           </div>
            </div>


            



       


         

    

<!-- 
                    <div id="products-app" style="margin-top:150px;">
        <div class="container">
            <div class="row">
                <h1>Customize Cake</h1>
                <div class="col-md-12">
                </div>
                
                <div class="col-md-6">
                    
                    <form @submit.prevent="fnSave($event)">
                        <textarea class="form-control mb-4" name="Suggestion"  placeholder="Suggestion"></textarea>
                        <textarea class="form-control mb-4" name="message" placeholder="Message"></textarea>
                        <select name="size" id="size" class="form-control mb-4">
                            <option selected disabled hidden>Size</option>
                          <option value="250" >Small : &#8369;250.00</option>
                          <option value="350" >medium : &#8369;350.00</option>
                          <option value="450">Large : &#8369;450.00</option>
                        </select>
                        <input class="form-control mb-4" required type="text" name="flavor" placeholder="flavor"  />
                        <input class="form-control mb-4" required type="number" name="quantity" placeholder="Quantity" />
                        <input class="form-control mb-4" required type="text" name="price" placeholder="Unit Price" v-model="price" />
                        <input class="form-control mb-4" type="file" name="productimage" />
                        <button class="btn btn-primary btn-lg" type="submit">Customize</button>
                    </form>
                </div>
            </div>
        </div>
    </div> -->


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/vue.3.js"></script>
<script src="js/axios.js"></script>
 <script src="js/script.js"></script>
<?php echo $app; ?>
</body>
</html>

       
    
