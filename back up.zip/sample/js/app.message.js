const {createApp} = Vue;

createApp({
    data(){
        return{

        }
    },
    methods:{
        fnSave:function(e){
            // console.log(e.target)
            const data = new FormData(e.target)
            data.append('method','fnMessage')
            axios.post('model/userModel.php',data).then(respond =>{
                console.log(respond.data)
            })

        }
    }
}).mount('#products-app')