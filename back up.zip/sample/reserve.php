<?php 

session_start();

if(!isset($_SESSION['userid'])){
    header('location:login.php');
}
    // $app = "<script src='js/app.register.js'></script>";
    // $fullname = isset($_SESSION['fullname']) ? $_SESSION['fullname'] : '';
    // $role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- <link rel="stylesheet" href="css/style.css"> -->
      <link rel="stylesheet" href="style.css">
       <!-- <link rel="stylesheet" href="bootstrap.css"> -->

	<title>Reserve</title>
</head>
<style>
    body{
           align-items: center;
    background-size: cover;
    background-position: center center;
      margin: 0;
    padding: 0;
    font-family: sans-serif;
    background: linear-gradient(to right,skyblue,white);
    }
    </style>
<body>
<!-- 		     <div class="container justify-content-sm-start my-2 mb-2">
                        <button  class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addproduct">Add Product</button>
                    </div>
                              
                                <div class="modal fade" tabindex="-1" id="addproduct">
                <div class="modal-dialog modal-dialog-centered">
                  <div class="modal-content p-4s">
                    <div class="modal-header">
                        <h5>Add PRODUCT</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                        <div class="modal-body p-4" id="products-app" >
                        <form @submit="fnSave($event)">
                        <input class="form-control mb-2" required type="text" name="productname" placeholder="Product Name" v-model="productname" />
                        <textarea class="form-control mb-2 " name="description" v-model="description" placeholder="Description"></textarea>
                        <input class="form-control mb-2" required type="number" name="quantity" placeholder="Quantity" v-model="quantity" />
                        <input class="form-control mb-2" required type="text" name="price" placeholder="Unit Price" v-model="price" />
                        <input class="form-control mb-2" type="file" name="productimage" />
                        
    
                            <button type="submit" class="btn btn-info float-end mt-3">Add</button>
                            <button type="button" class="btn btn-outline-secondary float-end mt-3 me-2" data-bs-dismiss="modal">Cancel</button>
                        </form> 
                    </div>
                    
                  </div>
                </div>
            </div> -->

    <!--         <div class="container justify-content-sm-start my-2 mb-2">
             <div class="form-group p-4" id="products-app" >
                        <form @submit="fnSave($event)" >
                        <input  required type="text" name="productname" placeholder="Product Name" v-model="productname" />
                        <textarea  name="description" v-model="description" placeholder="Description"></textarea>
                        <input  required type="number" name="quantity" placeholder="Quantity" v-model="quantity" />
                        <input  required type="text" name="price" placeholder="Unit Price" v-model="price" />
                        <input  type="file" name="productimage" />
                        
    
                            <button type="submit" class="btn btn-info float-end mt-3">Add</button>
                            <button type="button" class="btn btn-outline-secondary float-end mt-3 me-2" data-bs-dismiss="modal">Cancel</button>
                        </form> 
                    </div>
                </div> -->

   <header class="header">
        <div class="logoContent">
            <a href="#" class="logo"><img src="img/logo.png" alt=""></a>
            <h1 class="logoName">CakeEace </h1>
        </div>

        <nav class="navbar">
            <a href="indexx.php">HOME</a>
            <a href="indexx.php">ABOUT</a>
            <a href="indexx.php">MENU</a>
            <a href="reserve.php">RESERVE</a>
            <a href="indexx.php">CONTACT</a>
            <a href="logout.php">Account</a>
        </nav>

        <div class="icon">
            <i class="fas fa-search" id="search"></i>
            <i class="fas fa-bars" id="menu-bar"></i>
        </div>

        <div class="search">
            <input type="search" placeholder="search...">
        </div>
    </header>

  <div id="products-app" style="margin-top:150px;">
        <div class="container">
            <div class="row">
                <h1>Customize Cake</h1>
                <div class="col-md-12">
                </div>
                
                <div class="col-md-6">
                    
                    <form @submit.prevent="fnSave($event)">
                        <textarea class="form-control mb-4" name="Suggestion"  placeholder="Suggestion"></textarea>
                        <textarea class="form-control mb-4" name="message" placeholder="Message"></textarea>
                        <select name="size" id="size" class="form-control mb-4">
                            <option selected disabled hidden>Size</option>
                          <option value="250" >Small : &#8369;250.00</option>
                          <option value="350" >medium : &#8369;350.00</option>
                          <option value="450">Large : &#8369;450.00</option>
                        </select>
                        <input class="form-control mb-4" required type="text" name="flavor" placeholder="flavor"  />
                        <input class="form-control mb-4" required type="number" name="quantity" placeholder="Quantity" />
                        <!-- <input class="form-control mb-4" required type="text" name="price" placeholder="Unit Price" v-model="price" /> -->
                        <input class="form-control mb-4" type="file" name="productimage" />
                        <button class="btn btn-primary btn-lg" type="submit">Customize</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
              <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script> -->
              <script src="css/css.js"></script>
              <script src="js/axios.js"></script>
              <script src="js/vue.3.js"></script>
              <script src="js/app.message.js"></script>
</body>
</html>