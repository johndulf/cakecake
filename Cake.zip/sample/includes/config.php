<?php

    $con = new mysqli("localhost","root","","project_db");

?>