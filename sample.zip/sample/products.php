<?php 
    
    include "includes/header.php";
    $app = "<script src='js/app.products.js'></script>";
    $fullname = isset($_SESSION['fullname']) ? $_SESSION['fullname'] : '';
    $role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
?>
<!DOCTYPE html>
<html>
<head>
 <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="css/style.css">
    <title>Dashboard</title>
</head>
<body>
  
 <div class="d-flex" id="wrapper">
        <!--sidebar starts here-->

        <div class="bg-black" id="sidebar-wrapper">
            
            <div class="sidebar-heading text-center py-4 text-light fs-4 fw-bold text-uppercase border-bottom">
                <img src="../img/admin.png" width="100" height="100" alt="logo" > ADMIN
            </div>

            <div class="list-group list-group-flush my-3">
                <a href="dashboard.php" class="list-group-item list-group-item-action bg-transparent second-text active">
                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard 
                </a>
                <a href="userlist.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                    <i class="fa fa-user  me-2" aria-hidden="true"></i> User
                </a>
                <a href="" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                    <i class="fas fa-user-tie me-2"></i> Seller
                </a>
                 <a href="" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                    <i class="fas fa-receipt me-2"></i> Message
                </a> 
                   <a href="" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                    <i class="fas fa-receipt me-2"></i> Products
                </a> 
                <a href="logout.php" class="list-group-item list-group-item-action bg-transparent text-danger fw-bold" id="btn_logout">
                    <i class="fa-solid fa-right-from-bracket me-2"></i> Log Out
                </a>
            </div>

        </div>

        <!--sidebar ends here-->

       <div id="page-content-wrapper">

           
                <nav class="navbar navbar-expand-lg navbar-light bg-transparent py-4 px-4">
                    <div class="d-flex align-item-center">
                        <i class="fas fa-align-left primary-text fs-4 me-3" id="menu-toggle"></i>
                        <h2 class="fs-2 m-0">Menu</h2>
                    </div>    
                    
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>   
                    
                </nav>


                <div class="container-fluid row my-5" id="user">
                    <div class="input-group rounded row">
                        <h3 class="fs-4 mb-3 col">List of Product</h3>
                        <div class="col-12 col-lg-3">  
                            <div class="col mt-2 mb-3">
                                <input type="search" v-model="search" @input="searchUser(search)" class="form-control" placeholder="Search User">
                            </div>
                        </div>
                    </div>

       <!--       <div class="container-fluid px-4" >
                

                <div class="row g-3 my-2">
                    <div class="col-md-3">
                        <div class="p-3 bg-white shadow-sm d-flex justify-content-around align-items-center rounded">
                            <div>
                                <h3 class="fs-2" id="student">User</h3>                               

                                
                            </div>
                            <i class="fa fa-users fs-1 text-info bg-black border rounded-full secondary-bg p-3" aria-hidden="true"  ></i>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="p-3 bg-white shadow-sm d-flex justify-content-around align-items-center rounded">
                            <div>
                                <h3 class="fs-2" id="fees">Seller</h3>                                
                          
                            </div>
                            <i class="fas fa-user-tie fs-1 text-info bg-black border rounded-full secondary-bg p-3 "></i>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="p-3 bg-white shadow-sm d-flex justify-content-around align-items-center rounded">
                            <div>
                                <h3 class="fs-2" id="fees">Product</h3>                                
                                
                            </div>
                            <i class="fa fa-product-hunt fs-1 text-info bg-black border rounded-full secondary-bg p-3 "></i>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div> --> 

  <div id="products-app" style="margin-top:50px;">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                </div>
                <?php if($role == 2): ?>
                
                <div class="col-md-6">
                    
                    <form @submit="fnSave($event)">
                        <input class="form-control" required type="text" name="productname" placeholder="Product Name" v-model="productname" /><br>
                        <textarea class="form-control" name="description" v-model="description" placeholder="Description"></textarea><br>
                        <input class="form-control" required type="number" name="quantity" placeholder="Quantity" v-model="quantity" /><br>
                        <input class="form-control" required type="text" name="price" placeholder="Unit Price" v-model="price" /><br>
                        <input class="form-control" type="file" name="productimage" /><br>
        
                        <button class="btn btn-primary btn-lg" type="submit">Save</button>
                    </form>
                </div>
                <?php endif ?>
                <div>
                    <h1 style="text-align: center; margin-top: 100px; color: yellow;">MENU</h1>
                <div class="col-md-6">
                    <div class="row" v-for="product in products" style="border:2px solid black; margin: 10px;"  >
                        <div class="col-md-4"><img class="img-fluid" :src="'uploads/' + product.image" / style="margin:15px"></div>
                        <div class="col-md-8" style="font-size: 25px; color: white;">
                            Product Name: {{ product.productname }}<br>
                            Description: {{ product.description }}<br>
                            Quantity: {{ product.quantity }}<br>
                            Price: {{ product.price }} <br>

                             <?php if($role == 1): ?>
                            <button class="btn btn-primary btn-lg" style="margin-right:10px;" @click="">Buy</button>
                            <?php endif ?>
                            
                              <?php if($role == 2): ?>
                            <button class="btn btn-danger"  @click="DeleteProducts(product.productid)">Delete</button>
                                <button class="btn btn-success float-center m-3" @click="fnGetProdcuts(product.productid)"  data-bs-toggle="modal" data-bs-target="#updateSt">Update</button>
                             <?php endif ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    

       
<script src="js/vue.3.js"></script>
<script src="js/axios.js"></script>
<?php echo $app; ?>
 <script src="js/script.js"></script>

</body>
</html>
    
