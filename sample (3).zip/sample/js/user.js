const { createApp } = Vue;
createApp({
    data(){
        return{
            users:[],
            // search[],
            userid:0,
            fullname:'',
            username:'',
            password:'',
            address:'',
            mobile:'',
            email:''
        }
    },
    methods:{
        fnGetUsers:function(){
            const vm = this;
            const data = new FormData();
          data.append('method','fnGetUsers');
          axios.post('model/userModel.php',data)
          .then(function(r){
            vm.users = [];
              for(var v of r.data){
                vm.users.push({
                    fullname : v.fullname,
                    username : v.username,
                      password : v.password,
                      address : v.address,
                      mobile : v.mobile,
                      email : v.email,
                      userid : v.userid
                  })
              }
          })
        },
        // searchStud: function(search) {
        //   var data = new FormData();
        //   const vue = this;
        //   data.append('method','getStudents');
        //   axios.post('../includes/model.php',data)
        //     .then(function(r) {
        //       vue.studs = [];
        //       for (var v of r.data) {
        //           if (v.student_id.toString().includes(search.toString()) ||
        //           v.last_name.toLowerCase().includes(search.toLowerCase()) ||
        //           v.first_name.toLowerCase().includes(search.toLowerCase()) ||
        //           v.course.toLowerCase().includes(search.toLowerCase()) ||
        //           v.year_sec.toLowerCase().includes(search.toLowerCase()) ||
        //           v.email.toLowerCase().includes(search.toLowerCase()) ||
        //           v.address.toLowerCase().includes(search.toLowerCase()) ||
        //           v.status.toString().includes(search.toString())) {
        //             vue.studs.push({
        //               student_id : v.student_id,
        //               last_name : v.last_name,
        //               first_name : v.first_name,
        //               course : v.course,
        //               year_sec : v.year_sec,
        //               email : v.email,
        //               address : v.address,
        //               status : v.status,
        //           })
        //         }
        //       }
        //   })
        // },

        
        dropUsers:function(userid){
          if(confirm("Are you Sure you Want to delete This STUDENT?")){
            const vm = this;
            const data = new FormData();
            data.append("method","dropUsers");
            data.append("userid",userid);
            axios.post('model/userModel.php',data)
            .then(function(r){
              vue.fnGetUsers();
            })
          }
        },
        getUsersId:function(userid){
            const vm = this;
            const data = new FormData();
          data.append('method','getUsersId');
          data.append("userid",userid);
          axios.post('../includes/model.php',data)
          .then(function(r){
            console.log(r.data);
            for(var v of r.data){
              vue.id = v.id;
              vue.student_id = v.student_id;
              vue.email = v.email;
              vue.status = v.status;

            }
          })
        },
        updateStud:function(e){
          e.preventDefault();
          var form = e.currentTarget;
          const vue = this;
          var data = new FormData(form);
          data.append("method","updateStud");
          data.append("id",this.id);
          axios.post('../includes/model.php',data)
          .then(function(r){
            if(r.data == 1){
              alert('Student Successfully Update');
              vue.getStudents();
              document.querySelector(".studform").reset();
            }
          });
        },
      },
      created:function(){
        this. getStudents();
      },
      mounted:function(){

      }
}).mount('#students-app');