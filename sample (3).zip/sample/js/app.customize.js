const {createApp} = Vue;

createApp({
    data(){
        return{
            customizes:[],
            userid:0,
            fullname:'',
            suggestion:'',
            message:'',
            quantity:'',
            mobile:'',
            image:"",
            // size:'',
            // flavor:'',
            // date:'',
            // price:'',
        }
    },
    methods:{
        fnSave:function(e){
            const vm = this;
            e.preventDefault();    
            var form = e.currentTarget;
            const data = new FormData(form);
            data.append("userid",this.userid);
            data.append('method','fnSave');
            axios.post('model/customizeModel.php',data)
            .then(function(r){
                console.log(r);
                if(r.data == 1){
                    alert("User successfully  Customize");
                    // window.location.href = 'products.php';
                    vm.fnGetCustomize(0);
                }
                else{
                    alert('There was an error.');
                }
            })
        },
        DeleteCustomize:function(userid){
            if(confirm("Are you sure you want to delete this product?")){
                // window.location.href = 'products.php';
               const data = new FormData();
                  const vm = this;
                data.append("method","DeleteCustomize");
                data.append("userid",userid);
                axios.post('model/customizeModel.php',data)
                .then(function(r){
                    vm.fnGetCustomize();
                })
            }
        },
        fnGetCustomize:function(userid){
            const vm = this;
            const data = new FormData();
            data.append("method","fnGetCustomize");
            data.append("userid",userid);
            axios.post('model/customizeModel.php',data)
            .then(function(r){
                if(userid == 0){
                    vm.customizes = [];
                    
                    r.data.forEach(function(v){
                        
                            vm.customizes.push({
                                fullname :v.fullname,
                                suggestion: v.suggestion,
                                message: v.message,
                                quantity : v.quantity,
                                // price:v.price,
                                // userid:v.userid,
                                // size:v.size,
                                // flavor:v.flavor,
                                // date:v.date,
                                mobile: v.mobile,
                                image: v.image
                                // price:v.price
                            })
                                            
                        
                    });
                    //console.log(vm.products);
                }
                else{
                    r.data.forEach(function(v){
                        vm.fullname = v.fullname;
                        vm.suggestion = v.suggestion;
                        vm.message = v.message;
                        vm.quantity = v.quantity;
                        // vm.price = v.price;
                        vm.userid = v.userid;
                        // vm.flavor = v.flavor;
                        
                    })
                }
            })
        }
    },
      
    created:function(){
        this.fnGetCustomize(0);
    }
}).mount('#customize-app')