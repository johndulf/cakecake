const { createApp } = Vue;
createApp ({
   data(){
        return{
            users:[],
            // search[],
            userid:0,
            fullname:'',
            username:'',
            password:'',
            address:'',
            mobile:'',
            email:''
        }
   },
   methods:{
    fnSave:function(e){
        const vm = this;
        e.preventDefault();    
        var form = e.currentTarget;
        const data = new FormData(form);
        data.append("userid",this.userid);
        data.append('method','fnSave');
        axios.post('model/userModel.php',data)
        .then(function(r){
            console.log(r);
            if(r.data == 0){
                alert("User successfully saved");
                 window.location.href = 'userlist.php';
                //    document.querySelector("#update").reset();
                // vm.fnGetUsers(0);
            }
            else if(r.data == 1){
                alert('Already Registered');
            }
            else{
                alert('There was an error.');
            }
        });
    },
    fnGetUsers:function(){
        const vm = this;
        const data = new FormData();
      data.append('method','fnGetUsers');
      axios.post('model/userModel.php',data)
      .then(function(r){
        vm.users = [];
          for(var v of r.data){
            vm.users.push({
                fullname : v.fullname,
                username : v.username,
                  password : v.password,
                  address : v.address,
                  mobile : v.mobile,
                  email : v.email,
                  userid : v.userid
              })
          }
      })
    },
    DeleteUser:function(userid){
        if(confirm("Are you sure you want to delete this user?")){
            // document.querySelector("#delete").reset();
            const data = new FormData();
            const vm = this;
            data.append("method","DeleteUser");
            data.append("userid",userid);
           axios.post('model/userModel.php',data)
            .then(function(r){
                vue.fnGetUsers();
            })
        }
    },
      getUsersId:function(userid){
          const vm = this;
          const data = new FormData();
        data.append('method','getUsersId');
        data.append("userid",userid);
        axios.post('model/userModel.php',data)
        .then(function(r){
          console.log(r.data);
          for(var v of r.data){
            vm.userid = v.userid;
            vm.fullname = v.fullname;
            vm.username = v.username;
            vm.address = v.address;
            vm.mobile = v.mobile;
            vm.email = v.email;

          }
        })
      },
      updateUser:function(e){
        e.preventDefault();
        var form = e.currentTarget;
        const vm = this;
        const data = new FormData();
        data.append("method","updateUser");
        data.append("userid",this.userid);
        axios.post('model/userModel.php',data)
        .then(function(r){
          if(r.data == 1){
            alert('Successfully Update');
            vue.fnGetUsers();
            // document.querySelector(".studform").reset();
          }
        });
      },
    
   },
   
   created:function(){
   }
    
}).mount('#register');