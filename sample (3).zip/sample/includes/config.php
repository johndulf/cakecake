<?php

    $con = new mysqli("localhost","root","","cake_db");

?>