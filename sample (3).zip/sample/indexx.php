<?php 
    
    $app = "<script src='js/app.products.js'></script>";
    // $fullname = isset($_SESSION['fullname']) ? $_SESSION['fullname'] : '';
    // $role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>CakeEace</title>

    <!-- cdn icon link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- custom css file  -->
       <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- <link rel="stylesheet" href="style.css"> -->
    <link rel="stylesheet" href="styles.css">

      <link rel = "icon" href = "img/logo.png" type = "image/x-icon">

</head>

<body>

    <!-- header section start here  -->
    <header class="header">
        <div class="logoContent">
            <a href="#" class="logo"><img src="img/logo.png" alt=""></a>
            <h1 class="logoName">CakeEace </h1>
        </div>

        <nav class="navbar">
            <a href="#home">HOME</a>
            <a href="#ABOUT">ABOUT</a>
            <a href="menu.php">MENU</a>
            <a href="reserve.php">RESERVE</a>
            <a href="#contact">CONTACT</a>
            <div class="dropdown">
  <a class="dropdown-toggle"  data-bs-toggle="dropdown" aria-expanded="false">
  Account
</a>
  <ul class="dropdown-menu">
    <li><a class="dropdown-item" href="profile.php">Profile</a></li>
    <li><a class="dropdown-item" href="logout.php">Logout</a></li>
  </ul>
</div>
        </nav>

        <div class="icon">
            <i class="fas fa-search" id="search"></i>
            <i class="fas fa-bars" id="menu-bar"></i>
        </div>

        <div class="search">
            <input type="search" placeholder="search...">
        </div>
    </header>
    <!-- header section end here  -->

    <!-- home section start here  -->
    <section class="home" id="home">
        <div class="homeContent">
            <h2>Delicious Cake for Everyone </h2>
            <p>Unang Kagat Diabetes Agad</p>
            <div class="home-btn">
                <a href="reserve.php"><button>Reserve</button></a>
            </div>
        </div>
    </section>

    <!-- home section end here  -->

  

    <h1 style="color: black; background-color: white; text-align: center; font-family:emoji; font-size:35px;" class="m-3">ABOUT</h1>
  <section class="features" id="ABOUT">
    <div class="feature-container">
      <img src="images/menu1.jpg" alt="Flexbox Feature">
      <h2>Cakes</h2>
      <p>awwwawww</p>
    </div>
    <div class="feature-container">
      <img src="images/menu5.jpg" alt="Flexbox Feature">
      <h2>CSS Grid Navigation</h2>
      <p></p>
    </div>
    <div class="feature-container">
      <img src="images/menu6.jpg" alt="Flexbox Feature">
      <h2>Basic HTML5</h2>
      <p></p>
    </div>

  </section>

    <!-- product section end here  -->



    <div  id="products-app" >
     <h1 class="products" style="color:black;font-size:35px; font-family:emoji; text-align:center;" >Menu</h1>
      <div class="all-products">
         <div class="product" v-for="product in products">
            <img class="img-fluid" :src="'uploads/' + product.image"/>
            <div class="product-info">  {{ product.description }}
               <h4 class="product-title">{{ product.productname }}
               </h4>
               <p class="product-price" style="color: black"> P{{ product.price }}</p>
                            <button class="btn btn-primary float-center m-1" style="margin-right:10px;" @click=""data-bs-toggle="modal" data-bs-target="#reserve" >Reserve</button>


            </div>
         </div>
       </div>


       <div class="modal fade" tabindex="-1" id="reserve">
                <div class="modal-dialog modal-dialog-centered">
                  <div class="modal-content p-4s">
                    <div class="modal-header">
                        <h5>Reserve</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body p-4"  >
                    <form @submit="fnSave($event)">
                <input class="form-control mb-2" required type="text" name="productname" placeholder="Product Name" v-model="productname" />
                        <input class="form-control mb-2" required type="number" name="quantity" placeholder="Quantity" v-model="quantity" />
                        <input class="form-control mb-2" required type="text" name="price" placeholder="500" v-model="price"  disabled />
                    

                        <select name="size" id="size" class="form-control mb-2">
                               <option value="size" disabled>Size</option>
                            <option value="Small">Small</option>
                            <option value="medium">Medium</option>

                            <option value="large">Large</option>



                        </select>

                      <button  type="submit" class="btn btn-outline-success float-end mt-3"  >Reserve</button>
                      <button type="button" class="btn btn-outline-info float-end mt-3 me-2" data-bs-dismiss="modal">Cancel</button>
            </form>
                    </div>
                    
                  </div>
                </div>
            </div>
            
      </div>
      </div>
      </div>
      </div> 

  


  
    <!-- footer section start here  -->

    <footer class="footer" id="contact">
        <div class="box-container">
            <div class="mainBox">
                <div class="content">
                    <a href="#"><img src="img/cake1.png" alt=""></a>
                </div>

            </div>
            <div class="box">
                <h3>Quick link</h3>
                <a href="#"> <i class="fas fa-arrow-right"></i>Home</a>
                <a href="#"> <i class="fas fa-arrow-right"></i>ABOUT</a>
                <a href="#"> <i class="fas fa-arrow-right"></i>MENU</a>


            </div>
     <!--        <div class="box">
                <h3>Extra link</h3>
                <a href="#"> <i class="fas fa-arrow-right"></i>Account info</a>
                <a href="#"> <i class="fas fa-arrow-right"></i>order item</a>
                <a href="#"> <i class="fas fa-arrow-right"></i>privacy policy</a>
                <a href="#"> <i class="fas fa-arrow-right"></i>payment method</a>
                <a href="#"> <i class="fas fa-arrow-right"></i>our  services</a>
            </div> -->
            <div class="box">
                <h3>Contact Info</h3>
                <a href="#"> <i class="fas fa-phone"></i>+699339102</a>
                <a href="#"> <i class="fas fa-envelope"></i>awaw@gmail.com</a>

            </div>

        </div>
        <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
            <a href="#" class="fab fa-pinterest"></a>
        </div>
        <div class="credit">
            created by <span>Team Jej </span> |all rights reserved ! 
        </div>
    </footer>










    <!-- custom js file  -->
    <script src="css/css.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
<script src="css/css.js"></script>
<script src="js/vue.3.js"></script>
<script src="js/axios.js"></script>
<?php echo $app; ?>
 <script src="js/script.js"></script>


</body>

</html>