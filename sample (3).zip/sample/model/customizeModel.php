<?php 

include "../includes/config.php"; 

session_start();

$method = $_POST['method'];

if(function_exists($method)){ //fnSave
    call_user_func($method);
}
else{
    echo "Function not exists";
}

function fnSave(){
    global $con;
    $fullname = $_POST['fullname'];
    $suggestion = $_POST['suggestion'];
    $message = $_POST['message'];
    // $size = $_POST['size'];
    // $price = $_POST['price'];
    //  $flavor = $_POST['flavor'];
    $mobile = $_POST['mobile'];
    $quantity= $_POST['quantity	'];
    // $date= $_POST['date'];
    $userid = $_POST['userid'];
    $filename = $_FILES['productimage']['name'];
    $folder = '../uploads/';
    $destination = $folder . $filename;
    move_uploaded_file($_FILES['productimage']['tmp_name'],$destination);

    $query = $con->prepare('call sp_SaveCustomize(?,?,?,?,?,?,?)');
    $query->bind_param('isssiis',$userid,$fullname,$suggestion,$message,$quantity,$mobile,$destination);
    
    if($query->execute()){
        echo 1;
    }
    else{
        echo json_encode(mysqli_error($con));
    }

}

function fnGetCustomize(){
    global $con;
    $userid = $_POST['userid'];
    if($userid == 0){
        $query = $con->prepare("SELECT * FROM tbl_customize");
    }
    else{
        $query = $con->prepare("SELECT * FROM tbl_customize where userid = $userid");
    }
    
    $query->execute();
    $result = $query->get_result();
    $data = array();
    while($row = $result->fetch_array()){
        $data[] = $row;
    }

    echo json_encode($data);

}

 function DeleteCustomize(){
        global $con;
        $userid = $_POST['userid'];
        $query = $con->prepare("DELETE FROM tbl_customize where userid = ?");
        $query->bind_param('i',$userid);
        $query->execute();
        $query->close();
        $con->close();
    }

function fnLogin(){
    global $con;
    $username = $_POST['username'];
    $password = md5($_POST['password']);
    
    $query = $con->prepare("call sp_login(?,?)");
    $query->bind_param('ss',$username,$password);
    $query->execute();
    $result = $query->get_result();
    $ret = '';
    while($row = $result->fetch_array()){
        
        if($row['ret'] == 1){
            $_SESSION['userid'] = $row['userid'];
            $_SESSION['fullname'] = $row['fullname'];
            // $_SESSION['username'] = $row['username'];
            // $_SESSION['address'] = $row['address'];
            // $_SESSION['mobile'] = $row['mobile'];
            // $_SESSION['email'] = $row['email'];
            // $_SESSION['password'] = $row['password'];
            $_SESSION['role'] = $row['user_role'];
        }
        $ret = $row['ret'];
    }

    echo $ret;

}

function fnUnlockAccount(){
    global $con;
    $userid = $_POST['userid'];
    $query = $con->prepare("UPDATE tbl_customize SET counterlock = 0 where userid = $userid");
    $query->execute();
    echo 1;

}


?>